# AI巨浪中工程师的自留地 - 活动幻灯片

Desmond Zhou 主讲的自留地技术分享活动宣传页面。

## 活动信息

- **主讲人**: Desmond Zhou - Amazon Principal Engineer
- **主题**: AI巨浪中工程师的自留地
- **时间**: 2026年2月7日（周六）15:00 - 17:00
- **地点**: 200-3600 Number 3 Road, Richmond

## 在线预览

访问 GitHub Pages 查看幻灯片：
`https://你的用户名.github.io/仓库名/`

## 本地预览

直接用浏览器打开 `index.html` 文件即可。

## 关于自留地

自留地是一个技术专业人士社区，致力于为工程师提供交流与思考的平台。

访问官网：[www.ziliudi.io](https://www.ziliudi.io)
